package fr.licence.essai4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class DefinirTemps extends AppCompatActivity {

    private TextView timeChrono;
    private Button addTimeChrono, subTimeChrono, mNextButton2;
    protected CheckBox defaultTimeLimit;
    private int clicks = 5, timeLimit = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.definir_temps);

        this.timeChrono = findViewById(R.id.time_chrono);
        this.addTimeChrono = findViewById(R.id.add_time_chrono);
        this.subTimeChrono = findViewById(R.id.sub_time_chrono);
        this.defaultTimeLimit = findViewById(R.id.checkbox1);
        this.mNextButton2 = findViewById(R.id.second_button);

        defaultTimeLimit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (defaultTimeLimit.isChecked()){
                    timeLimit = 10000;
                    getPreferences(MODE_PRIVATE).edit().putInt("Time_limit", timeLimit).commit();
                    addTimeChrono.setEnabled(false);
                    subTimeChrono.setEnabled(false);
                }
                else {
                    addTimeChrono.setEnabled(true);
                    subTimeChrono.setEnabled(true);
                }
            }
        });


        addTimeChrono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicks++;
                timeChrono.setText(clicks + " min");
                timeLimit = clicks;
                getPreferences(MODE_PRIVATE).edit().putInt("Time_limit", timeLimit).commit();
            }
        });

        subTimeChrono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    if (clicks > 1) {
                        clicks--;
                        timeChrono.setText(clicks + " min");
                        timeLimit = clicks;
                        getPreferences(MODE_PRIVATE).edit().putInt("Time_limit", timeLimit).commit();
                    }
                    else {
                        timeChrono.setText("1 min");
                        timeLimit = 1;
                        getPreferences(MODE_PRIVATE).edit().putInt("Time_limit", timeLimit).commit();
                    }
            }
        }

        });

        mNextButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent PierreFeuilleCiseaux = new Intent(getApplicationContext(), PierreFeuilleCiseaux.class);
                startActivity(PierreFeuilleCiseaux);
            }
        });

}}