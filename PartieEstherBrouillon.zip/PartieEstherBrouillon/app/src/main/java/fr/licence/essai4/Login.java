package fr.licence.essai4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    protected Button mNextButton;
    private EditText mName1, mName2;
    SharedPreferences namePlayer1, namePlayer2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        this.mName1 = findViewById(R.id.Name1);
        this.mName2 = findViewById(R.id.Name2);
        this.mNextButton = findViewById(R.id.main_first_button);

        mNextButton.setEnabled(false);


        mName1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                mNextButton.setEnabled((mName1.getText().length() >= 1) && (mName2.getText().length() >= 1));
            }

            });

        mName2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence t, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence t, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable t) {
                mNextButton.setEnabled((mName1.getText().length() >= 1) && (mName2.getText().length() >= 1));
            }
        });

        String name1 = mName1.getText().toString();
        String name2 = mName2.getText().toString();

        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                SharedPreferences preferences = getSharedPreferences("PLAYERS_NAMES", Context.MODE_WORLD_WRITEABLE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("namePlayer1", mName1.getText().toString());
                editor.putString("namePlayer2", mName2.getText().toString());
                editor.apply();

                Intent DefinirTemps = new Intent(getApplicationContext(), DefinirTemps.class);
                startActivity(DefinirTemps);
            }
        });

    }
    }