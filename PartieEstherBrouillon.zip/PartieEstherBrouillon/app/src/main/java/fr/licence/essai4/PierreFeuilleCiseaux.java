package fr.licence.essai4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.view.View.OnClickListener;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class PierreFeuilleCiseaux extends AppCompatActivity {

    private TextView mnamePlayer1, mnamePlayer2, mcaseEgality, mtexteDePresentation;
    private ImageButton mleaf1, mstone1, mchisel1;
    private ImageButton mleaf2, mstone2, mchisel2;
    private Button mnextButton3;
    private int isChoisi1 = 0, isChoisi2 = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pierre_feuille_ciseaux);

        this.mleaf1 = findViewById(R.id.leaf_player1);
        this.mstone1 = findViewById(R.id.stone_player1);
        this.mchisel1 = findViewById(R.id.chisel_player1);
        this.mleaf2 = findViewById(R.id.leaf_player2);
        this.mstone2 = findViewById(R.id.stone_player2);
        this.mchisel2 = findViewById(R.id.chisel_player2);
        this.mnamePlayer1 = findViewById(R.id.NamePlayer1);
        this.mnamePlayer2 = findViewById(R.id.NamePlayer2);
        this.mcaseEgality = findViewById(R.id.case_egality);
        this.mnextButton3 = findViewById(R.id.third_button);
        this.mtexteDePresentation = findViewById(R.id.TexteDePresentation);


        SharedPreferences prfs = getSharedPreferences("PLAYERS_NAMES", Context.MODE_PRIVATE);
        String Name_player1 = prfs.getString("namePlayer1", "");
        String Name_player2 = prfs.getString("namePlayer2", "");
        mnamePlayer1.setText(Name_player1 + " , à votre tour :");
        mnamePlayer2.setText(Name_player2 + " , à votre tour :");

                mcaseEgality.setVisibility(View.INVISIBLE);

                mnamePlayer1.setVisibility(View.VISIBLE);
                mleaf1.setVisibility(View.VISIBLE);
                mstone1.setVisibility(View.VISIBLE);
                mchisel1.setVisibility(View.VISIBLE);

                mnamePlayer2.setVisibility(View.INVISIBLE);
                mleaf2.setVisibility(View.INVISIBLE);
                mstone2.setVisibility(View.INVISIBLE);
                mchisel2.setVisibility(View.INVISIBLE);

                mnextButton3.setVisibility(View.INVISIBLE);

                mleaf1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi1 = 1;
                        mnamePlayer1.setVisibility(View.INVISIBLE);
                        mleaf1.setVisibility(View.INVISIBLE);
                        mstone1.setVisibility(View.INVISIBLE);
                        mchisel1.setVisibility(View.INVISIBLE);

                        mnamePlayer2.setVisibility(View.VISIBLE);
                        mleaf2.setVisibility(View.VISIBLE);
                        mstone2.setVisibility(View.VISIBLE);
                        mchisel2.setVisibility(View.VISIBLE);
                    }
                });

                mstone1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi1 = 2;
                        mnamePlayer1.setVisibility(View.INVISIBLE);
                        mleaf1.setVisibility(View.INVISIBLE);
                        mstone1.setVisibility(View.INVISIBLE);
                        mchisel1.setVisibility(View.INVISIBLE);

                        mnamePlayer2.setVisibility(View.VISIBLE);
                        mleaf2.setVisibility(View.VISIBLE);
                        mstone2.setVisibility(View.VISIBLE);
                        mchisel2.setVisibility(View.VISIBLE);
                    }
                });

                mchisel1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi1 = 3;
                        mnamePlayer1.setVisibility(View.INVISIBLE);
                        mleaf1.setVisibility(View.INVISIBLE);
                        mstone1.setVisibility(View.INVISIBLE);
                        mchisel1.setVisibility(View.INVISIBLE);

                        mnamePlayer2.setVisibility(View.VISIBLE);
                        mleaf2.setVisibility(View.VISIBLE);
                        mstone2.setVisibility(View.VISIBLE);
                        mchisel2.setVisibility(View.VISIBLE);
                    }
                });

                mleaf2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi2 = 1;
                        mnamePlayer2.setVisibility(View.INVISIBLE);
                        mleaf2.setVisibility(View.INVISIBLE);
                        mstone2.setVisibility(View.INVISIBLE);
                        mchisel2.setVisibility(View.INVISIBLE);
                        mtexteDePresentation.setVisibility(View.INVISIBLE);

                        if (isChoisi1 == isChoisi2){
                            mcaseEgality.setVisibility(View.VISIBLE);
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener(){
                                @Override
                                public void onClick(View v){
                                    Intent PierreFeuilleCiseaux = new Intent(getApplicationContext(), PierreFeuilleCiseaux.class);
                                    startActivity(PierreFeuilleCiseaux);
                                }
                            });
                        }
                        else{
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v){
                                    AlertDialog alertDialog = new AlertDialog.Builder(PierreFeuilleCiseaux.this).create();
                                    switch(isChoisi1){
                                        case 1:
                                            if (isChoisi2 == 2)
                                                alertDialog.setMessage("La feuille bat la pierre...\n" + Name_player1 + " va commencer !");
                                            else if(isChoisi2 == 3)
                                                alertDialog.setMessage("La feuille est battue par les ciseaux...\n" + Name_player2 + " va commencer !");
                                            break;
                                        case 2:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("La pierre est battue par la feuille...\n" + Name_player2 + " va commencer !");
                                            else if (isChoisi2 == 3)
                                                alertDialog.setMessage("La pierre bat les ciseaux...\n" + Name_player1 + " va commencer !");
                                            break;
                                        case 3:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("Les ciseaux battent la feuille...\n" + Name_player1 + " va commencer !");
                                            else if (isChoisi2 == 2)
                                                alertDialog.setMessage("Les ciseaux sont battus par la pierre...\n" + Name_player2 + " va commencer !");
                                            break;
                                    }
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "JOUER", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent NextActivity  = new Intent(getApplicationContext(), NextActivity.class);
                                            startActivity(NextActivity);
                                        }
                                    });
                                    alertDialog.show();
                                }
                            });
                        }
                    }
                });

                mstone2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi2 = 2;
                        mnamePlayer2.setVisibility(View.INVISIBLE);
                        mleaf2.setVisibility(View.INVISIBLE);
                        mstone2.setVisibility(View.INVISIBLE);
                        mchisel2.setVisibility(View.INVISIBLE);
                        mtexteDePresentation.setVisibility(View.INVISIBLE);

                        if (isChoisi1 == isChoisi2){
                            mcaseEgality.setVisibility(View.VISIBLE);
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener(){
                                @Override
                                public void onClick(View v){
                                    Intent PierreFeuilleCiseaux = new Intent(getApplicationContext(), PierreFeuilleCiseaux.class);
                                    startActivity(PierreFeuilleCiseaux);
                                }
                            });
                        }
                        else{
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v){
                                    AlertDialog alertDialog = new AlertDialog.Builder(PierreFeuilleCiseaux.this).create();
                                    switch(isChoisi1){
                                        case 1:
                                            if (isChoisi2 == 2)
                                                alertDialog.setMessage("La feuille bat la pierre...\n" + Name_player1 + " va commencer !");
                                            else if(isChoisi2 == 3)
                                                alertDialog.setMessage("La feuille est battue par les ciseaux...\n" + Name_player2 + " va commencer !");
                                            break;
                                        case 2:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("La pierre est battue par la feuille...\n" + Name_player2 + " va commencer !");
                                            else if (isChoisi2 == 3)
                                                alertDialog.setMessage("La pierre bat les ciseaux...\n" + Name_player1 + " va commencer !");
                                            break;
                                        case 3:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("Les ciseaux battent la feuille...\n" + Name_player1 + " va commencer !");
                                            else if (isChoisi2 == 2)
                                                alertDialog.setMessage("Les ciseaux sont battus par la pierre...\n" + Name_player2 + " va commencer !");
                                            break;
                                    }
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "JOUER", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent NextActivity  = new Intent(getApplicationContext(), NextActivity.class);
                                            startActivity(NextActivity);
                                        }
                                    });
                                    alertDialog.show();
                                }
                            });
                        }
                    }
                });

                mchisel2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        isChoisi2 = 3;
                        mnamePlayer2.setVisibility(View.INVISIBLE);
                        mleaf2.setVisibility(View.INVISIBLE);
                        mstone2.setVisibility(View.INVISIBLE);
                        mchisel2.setVisibility(View.INVISIBLE);
                        mtexteDePresentation.setVisibility(View.INVISIBLE);

                        if (isChoisi1 == isChoisi2){
                            mcaseEgality.setVisibility(View.VISIBLE);
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener(){
                                @Override
                                public void onClick(View v){
                                    Intent PierreFeuilleCiseaux = new Intent(getApplicationContext(), PierreFeuilleCiseaux.class);
                                    startActivity(PierreFeuilleCiseaux);
                                }
                            });
                        }
                        else{
                            mnextButton3.setVisibility(View.VISIBLE);
                            mnextButton3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v){
                                    AlertDialog alertDialog = new AlertDialog.Builder(PierreFeuilleCiseaux.this).create();
                                    switch(isChoisi1){
                                        case 1:
                                            if (isChoisi2 == 2)
                                                alertDialog.setMessage("La feuille bat la pierre...\n" + Name_player1 + " va commencer !");
                                            else if(isChoisi2 == 3)
                                                alertDialog.setMessage("La feuille est battue par les ciseaux...\n" + Name_player2 + " va commencer !");
                                            break;
                                        case 2:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("La pierre est battue par la feuille...\n" + Name_player2 + " va commencer !");
                                            else if (isChoisi2 == 3)
                                                alertDialog.setMessage("La pierre bat les ciseaux...\n" + Name_player1 + " va commencer !");
                                            break;
                                        case 3:
                                            if (isChoisi2 == 1)
                                                alertDialog.setMessage("Les ciseaux battent la feuille...\n" + Name_player1 + " va commencer !");
                                            else if (isChoisi2 == 2)
                                                alertDialog.setMessage("Les ciseaux sont battus par la pierre...\n" + Name_player2 + " va commencer !");
                                            break;
                                    }
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "JOUER", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent NextActivity  = new Intent(getApplicationContext(), NextActivity.class);
                                            startActivity(NextActivity);
                                        }
                                    });
                                    alertDialog.show();
                                }
                            });
                        }
                    }
                });


        }
    }


